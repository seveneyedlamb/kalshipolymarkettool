# DESIGN - Harpoon Cannon
Concept C "Nautical Chart" SELECTED 2026-04-15

## Philosophy
3 things in <5sec: "looks expensive" + "doing something NOW" + "I need this"
Moby Dick = brand soul not skin. Rockwell Kent woodcut style. Captain's study not pirate party.

## Palette
bg: #0A1628 | surface: #111D33 | gold: #D4A752 | bone: #F5F0E8 | fog: #94A3B8
success: #22D3A0 | danger: #EF4444 | border: #1E3048 | gold-border: rgba(212,167,82,0.35)

## Typography
Display: EB Garamond | Body: Source Sans 3 | Data: IBM Plex Mono

## Art Direction
- Subtle chart paper texture 2% opacity
- 19th-century book ornamental rules as section dividers
- Compass rose loading spinner, depth soundings as data labels
- Woodcuts in 3 places ONLY: landing hero bg, tier pricing icons, empty states
- NOT cartoons, NOT clip art, NOT oil paintings, NOT full-color

## Pages

### Public (no auth)
/ = Landing: hero+live data feed, how it works, comparison(14 rows), pricing toggle(mo/yr), FAQ, milestone, footer+status badge
/pricing = 3 tiers, monthly/annual toggle, Polar+Coinremitter checkout
/login = Supabase Auth(email/pw, magic link)
/status = Binary health(operational|degraded). No component names. Middleware-exempt
/auth/callback = invisible redirect handler

### Dashboard (auth+tier required)
/dashboard = Pick Board: tier-filtered ranked picks, realtime, sort/filter, milestone bar
/dashboard/pick/[id] = Full analysis: rationale, PRO/CON+grades, evidence gap, risk, sentiment, community, bet btn, courtroom btn(modal upsell for H), share, feedback thumbs
/dashboard/markets = Market Scanner: tier-filtered table
/dashboard/bets = Bet Tracker: self-reported positions, direction-aware P&L, win celebration
/dashboard/referrals = Affiliate: link, clicks, signups, earnings, payouts, fleet viz
/dashboard/alerts = Alert History: chronological, read/unread
/dashboard/settings = Notif prefs, watchlist, billing+cancel(exit survey modal), BYOAI(visible all tiers, locked H), Send Feedback modal

### Admin (auth+is_admin)
/admin = Command Center: health RED/YEL/GRN, revenue, errors, scoring toggle
/admin/users = User table: email/tier/signup/login/bets/revenue/referred/status
/admin/affiliates = Top referrers, payouts, fraud flags
/admin/accuracy = Pick performance charts(P2)
/admin/feedback = user_feedback table, filter by type

## Shared Components
Navbar(logo+breadcrumb+avatar+tier+bell) | Sidebar(maritime icons, collapse mobile) | Pick Card(rank/title/platform/direction/edge/confidence/crowd/anomaly) | Evidence Badge(A=green B=blue C=yellow D=red) | Tier Badge(H=bronze FM=silver A=gold) | Milestone Bar(ship sailing to islands) | Toast | Modal(upsell/survey/feedback/celebration) | Loading Skeleton | Empty State(woodcut+text) | Share Button(+affiliate link) | Live Data Feed(scrolling analysis) | Comparison Chart(3-col animated) | Pricing Toggle(mo/yr)

## Responsive
Desktop 1280+: sidebar+main, 2-col where applicable
Tablet 768-1279: hamburger sidebar, single col, stacked cards
Mobile <768: bottom tab nav(5 tabs), no sidebar, simplified pick cards

## Hero Animation
50+ real market titles. Every 2-3s new market enters pipeline. Sequence: title fade-in→prob bar fill 1s→edge typewriter→gold "EDGE FOUND" if >15. 5-6 visible, oldest scrolls up+fades. Continuous loop.

## Schema Context
19 tables in 001_initial_schema.sql. Key page→table mapping:
admin/feedback→user_feedback | admin/users→user_profiles+user_bets+payments | status→system_state(admin client!) | events→user_events | pick detail→picks+courtroom_verdicts+user_feedback

## Tech
Next.js 14+ App Router TS | Tailwind+shadcn/ui(heavy customization) | Framer Motion(landing animations) | Recharts(dashboard charts) | Supabase Realtime(picks)
CSS vars mapped to shadcn system. Dark theme only. No light theme P1.
Fonts via next/font. SVGs in /public/brand/. Lighthouse 90+. LCP<2.5s. <500KB landing.
