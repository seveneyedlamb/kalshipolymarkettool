# CLAUDE.md - Harpoon Cannon Context

## What
Prediction market SaaS. Insider trading detection Kalshi+Polymarket. AI scores probability → compares market price → surfaces edge.

## Stack
Next.js 14+ App Router, TS only | Supabase (pg+auth+realtime) | Vercel Pro (ALL code) | Claude API | Polar (fiat) | Coinremitter (crypto) | shadcn/ui

## Rules
- SYNC-PROTOCOL.md = read first every session
- 001_initial_schema.sql = DB source of truth. Schema edit → update SQL same session
- Prices 0.00-1.00 float. Kalshi: parseFloat(yes_bid_dollars). Polymarket: JSON.parse(outcomePrices)→parseFloat. NEVER legacy cents
- All timestamps UTC. Browser converts display only
- Max 300 lines/file
- Tier filter: `WHERE min_tier IN ([allowed])` not rank compare
- Atomic locks: `UPDATE system_state SET value='running',updated_at=now() WHERE key='poller_lock' AND (value='idle' OR updated_at<now()-interval'3 min') RETURNING *` → 0 rows = skip
- Webhook idempotent: payments.provider_event_id UNIQUE
- Brand: "Harpoon Cannon Intelligence" user-facing. NEVER "Claude"/"Anthropic"
- Chargebacks = ban
- Anomaly: MIN 100 snapshots before activating
- Rate limit: dashboard 60/min/user, API 30/min/IP
- Sessions: Harpooner=2, FM=3, Ahab=5. Prune >30min
- Watermark rationale w/ invisible Unicode user_id
- SUPABASE_SERVICE_ROLE_KEY: server only. NEVER NEXT_PUBLIC_
- 3 Supabase clients: browser(client.ts)=RLS, server(server.ts)=user ctx, admin(admin.ts)=bypass RLS for crons/webhooks
- user_profiles auto-created by handle_new_user trigger. FE never creates
- Internal routes: dual auth Bearer CRON_SECRET OR HARPOON_INTERNAL_SECRET
- Poller: Promise.allSettled not Promise.all. One platform down ≠ both dead
- Connectors → NormalizedMarket interface (lib/platforms/types.ts)
- Middleware: check subscription_expires_at realtime, clear tier if expired
- Tier upgrade: Polar plan change API, NOT new checkout (=double billing)
- Voided markets: was_correct=NULL, P&L=0, excluded from accuracy
- Market status: active/closed/resolved. Kalshi: unopened|open→active, closed→closed, settled→resolved. Polymarket: active=true→active, closed=true→closed
- Pick Detail: check pick.min_tier vs user tier BEFORE render. Block if unauthorized

## Tables (19)
markets snapshots anomalies picks user_profiles user_bets user_watchlist market_views payments referrals affiliate_payouts notification_log system_state error_log active_sessions courtroom_verdicts user_events user_feedback waitlist

## Pick Board Query
```sql
SELECT cycle_id FROM picks ORDER BY scored_at DESC LIMIT 1;

SELECT picks.*, markets.yes_price, markets.crowd_views_24h,
       markets.crowd_bets_24h, markets.crowd_yes_pct
FROM picks JOIN markets ON picks.market_id = markets.id
WHERE (picks.cycle_id = [latest]
       OR (picks.is_whale_alert = true AND picks.scored_at > now() - interval '1 hour'))
  AND picks.min_tier IN ([allowed_tiers])
ORDER BY picks.pick_score DESC LIMIT [tier_limit]
```

## Routes (15)
poll-markets(cron/min) | analyze-markets(cron/hr) | analyze-urgent(POST) | webhook/fiat(POST) | webhook/crypto(POST) | send-notifications(POST) | resolve-picks(cron/day+demand) | aggregate-crowd(cron/15min) | track-view(POST) | check-expirations(cron/day) | milestone-status(GET/public) | process-payouts(cron/month) | validate-models(cron/week Sun 06:00 UTC) | courtroom(POST,P2) | settings/byoai(POST+DELETE,P2)

## Formulas
Edge YES: true_prob - (yes_price*100)
Edge NO: true_prob - ((1-yes_price)*100)
pick_score = abs(edge)*0.40 + conf_mult*0.25 + anomaly_bonus*0.15 + crowd_bonus*0.20
conf_mult: high=1.0 med=0.6 low=0.3
anomaly_bonus: 1.0 if active anomalies else 0
crowd_bonus: min(bets_24h/50,1.0) * abs(crowd_yes_pct-50)/50

## Tiers
Harpooner $29/mo|$290/yr: IN('harpooner') LIMIT 25. Credits:0. Cap:0. BYOAI:locked
First Mate $99/mo|$990/yr: IN('harpooner','first_mate') LIMIT 50. Credits:150/mo. Cap:20/day. BYOAI:300/day
Ahab $299/mo|$2990/yr: no filter no limit. Credits:500/mo. Cap:50/day. BYOAI:300/day
Annual=17% discount. Polar handles both. Webhook maps both IDs→same tier
Env: POLAR_HARPOONER_PRODUCT_ID + POLAR_HARPOONER_ANNUAL_PRODUCT_ID

## Models
Background (hourly): ALWAYS Haiku researcher→Sonnet analyst. ALL tiers same. Fixed cost
On-demand: Standard=Haiku(1cr) | Enhanced=Sonnet(3cr) | Premium=Opus(10cr)
NEVER expose model names to users. ANALYSIS_ENGINES in tier-features.ts

## Model Auto-Healing (CRITICAL)
SCORING_MODELS.{role} and ANALYSIS_ENGINES.{tier}.internal are ARRAYS (3-position fallback chains), not strings. Every AI call through lib/ai/call-with-fallback.ts. NEVER direct anthropic.messages.create(). On 404 not_found_error→try next position, cache winner in system_state.active_model_{role}. On 429/529/5xx→retry same model, then fall back. On 401→abort+admin alert. /api/validate-models cron (Sun 06:00 UTC) calls Anthropic GET /v1/models weekly, warns if positions [0] or [2] retired

## Credit Consumption (atomic)
MUST use atomic UPDATE...RETURNING. NEVER read-check-write. Pattern: (1) UPDATE user_profiles SET monthly_credits_used=monthly_credits_used+cost WHERE id=$user_id AND monthly_credits_used+cost<=tier_allowance RETURNING. If 0 rows→(2) RPC consume_bonus_credits handles shortfall atomically. Ships Phase 2 Session P2-7, not deferred.

## Credit Top-Ups (Phase 2)
Polar ONE-TIME products (not subs). Env: POLAR_BOOST_PRODUCT_ID, POLAR_POWER_PACK_PRODUCT_ID, POLAR_UNLIMITED_WARFARE_PRODUCT_ID. /api/buy-credits POST creates checkout w/ metadata {supabase_user_id, package_type, credit_amount}. webhook/fiat detects by product_id→UPDATE bonus_credits. event_type='credit_topup'. NO affiliate commission on top-ups

## Courtroom
POST /api/courtroom {pick_id,engine}. FM+Ahab only. 2 calls: Trial(Haiku)+Verdict(user engine). Cache 6hr or price>5%. Cap: FM 20/day, Ahab 50/day. BYOAI: 300/day separate

## Credits
Monthly: H=0 FM=150 A=500. Reset 1st (check-expirations). Purchased bonus_credits never expire, consumed after monthly. Cols: monthly_credits_used(int), bonus_credits(int)

## BYOAI
FM+Ahab own key (OpenAI/Anthropic/OpenRouter). 0 credits. 300/day. Lazy reset midnight UTC. AES-256-GCM w/ HARPOON_ENCRYPTION_SECRET. NEVER log key. NEVER return after save. NEVER fallback to our credits silently. Harpooner sees section VISIBLE+LOCKED=upsell. Cols: custom_ai_provider, custom_ai_key_encrypted, custom_ai_model, byoai_queries_today, byoai_reset_at

## Prompt Cache
System prompt identical every call. cache_control:{type:"ephemeral"} on system msg. Saves 90% on ~2K tokens/call

## Skip-if-Unchanged
Skip if ALL: last_analyzed_at NOT NULL + <4hr old + price_delta<0.03 + no new anomalies + not whale-triggered

## Parser: Claude JSON → picks
market_platform_id→lookup market_id | confidence→confidence_level(must=high/med/low) | direction→uppercase(must=YES/NO,reject else) | true_probability→0-100 int(reject if OOB/NaN) | edge→RECALCULATE(never trust Claude) | key_evidence→jsonb | social_sentiment→jsonb | evidence_gap→text | what_would_change→text
Engine-set: id cycle_id scored_at min_tier pick_score rank analysis_pool market_price_at_scoring is_whale_alert resolved was_correct actual_pnl_pct

## API Response Parse
web_search=multi-block. Filter content type==="text". Concat .text values. JSON.parse. NOT one string

## Error Pattern
try/catch/finally. Success→update system_state last_success_[fn]. Error→write error_log(source,error_type,details). Finally→release lock

## Full Spec
HARPOON-CANNON-v3-FINAL.md
