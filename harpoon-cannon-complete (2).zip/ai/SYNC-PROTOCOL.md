# SYNC-PROTOCOL
Read FIRST every session. Drift = #1 project threat.

## Rule Zero
Cannot update all affected files in one sitting → do not make edit.

## Canonical Values (change one → verify ALL locations)

Tables: 19 → SQL header + CLAUDE.md + REFERENCE.md + build guide S2 + arch doc ER + function map DATA
Routes: 15 → CLAUDE.md + arch doc function map + REFERENCE.md + vercel.json (7 crons incl validate-models)
Pricing: $29/$99/$299 mo | $290/$990/$2990 yr → arch doc + CLAUDE.md + build guide S9 + REFERENCE.md + design + HTML mockup
Daily cap: H=0 FM=20 Ahab=50 → arch TIER_FEATURES + courtroom section + defense section + CLAUDE.md + build guide + REFERENCE.md
Credits: H=0 FM=150 Ahab=500 → arch TIER_FEATURES + CLAUDE.md + REFERENCE.md
BYOAI cap: 300/day → arch BYOAI section + TIER_FEATURES + CLAUDE.md + REFERENCE.md + build guide
Env vars P1: 14 → arch doc total + REFERENCE.md list
Env vars P2 additions: 10 (incl POLAR_BOOST/POWER_PACK/UNLIMITED_WARFARE for top-ups) → arch doc
Sessions: P1=14 P2=7 P3=8 → arch + build guide + REFERENCE.md
Errors: 444 fixed (407 + Audit N 19 + N2-N3 18) → ERROR-HUNTER + REFERENCE.md
Files: 11 → REFERENCE.md + ERROR-HUNTER ripple list
CHECK constraints: 24 → SQL schema (defense-in-depth on enum-like text fields)
Model fallback: SCORING_MODELS & ANALYSIS_ENGINES.{t}.internal are ARRAYS of 3 positions each → arch + CLAUDE.md + REFERENCE.md

## Pre-Edit Checklist
1. Numeric value? → find in canonical values, update ALL locations
2. Schema change? → 001_initial_schema.sql + ER diagram + table lists + count refs
3. New/removed route? → function map + route count + CLAUDE.md + REFERENCE.md + build session
4. Tier change? → TIER_FEATURES + differentiator table + REFERENCE.md + fiscal math + design + HTML
5. UI structure? → design.md page map + arch route map + project structure
6. New env var? → arch list+count + REFERENCE.md list+count
7. Cron change? → vercel.json + arch cron table + build S14

## Post-Edit Audit
```bash
echo "SQL:$(grep -c '^CREATE TABLE' /mnt/user-data/outputs/001_initial_schema.sql)"
grep -rHn '19 tables\|Tables (19)' /mnt/user-data/outputs/*.md /mnt/user-data/outputs/*.sql 2>/dev/null | grep -v progress | grep -v ERROR
grep -rHn '20/day\|50/day\|300/day' /mnt/user-data/outputs/*.md 2>/dev/null | grep -v progress | grep -v ERROR | grep -v SYNC | grep -oE '20/day|50/day|300/day' | sort | uniq -c
grep -rHn 'Phase 1.*(14)\|launch: 14' /mnt/user-data/outputs/*.md 2>/dev/null | grep -v progress | grep -v ERROR | grep -v SYNC
```

## 11 Mermaid Diagrams (high drift zone)
System Arch | Poller Flow | Scoring Flow | Signal Categories | Route Map | ER Diagram | Gantt | Payment Flow | Notification Flow | Courtroom Flow | Function Map
Prose change affects diagram concept → update diagram same edit

## Known Hotspots
Pool threshold operators(>=0.7 >=0.3) | Table count header vs list | Env var count | Daily cap per-tier | Credited vs BYOAI counters | Function map V-count | DATA subgraph table list | TOC line numbers(always stale) | ai/ folder drift(mirror root edits here or regenerate from scratch)

## Enforcement
Every session: read this → make edits → run audit → report drift in progress.md → never declare done if inconsistent
