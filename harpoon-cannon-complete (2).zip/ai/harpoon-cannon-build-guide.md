# BUILD GUIDE - Harpoon Cannon

## Rules
BRICKLAYER: Phase N never modifies Phase N-1 code. ADD only. New files, routes, columns.
ERROR PATTERN: every bg fn → try/catch/finally. Success→update last_success. Error→write error_log. Finally→release lock.

# PHASE 1 (14 sessions)

Prereqs: Node.js, Supabase project, Vercel, Anthropic key, Polar, Coinremitter

### S1: Scaffold
Ctx: CLAUDE.md + Project Structure
Do: Next.js 14+ App Router TS Tailwind shadcn. Folder structure per CLAUDE.md. All page.tsx+route.ts stubs. lib/supabase/{browser,server,admin}.ts. .env.local
Check: dev server runs, all routes resolve

### S2: Database
Ctx: 001_initial_schema.sql (paste full)
Do: Run SQL in Supabase Editor. supabase gen types→src/types/database.ts
Check: 19 tables. Types file complete. Realtime on picks/anomalies/markets. handle_new_user trigger creates profile on signup

### S3: Connectors
Ctx: CLAUDE.md + API Field Reference
Do: lib/platforms/{kalshi,polymarket,types}.ts. NormalizedMarket interface. parseFloat prices→0-1. Pagination. Rate limits(100ms Kalshi). Validate: reject >1.0 or <0.0 or NaN
Check: test script logs counts+prices. All 0.0-1.0. No NaN

### S4: Nexus Tagger
Ctx: CLAUDE.md + Nexus Config
Do: lib/nexus/{config,tagger}.ts. Keywords+entities+policy domains. Case-insensitive. nexus_score=min(sum,1.0)
Check: "US strike Iran" → nexus>0.7 tags:iran,military

### S5: Poller
Ctx: CLAUDE.md + Engine 1 + Pre-Build Bugs
Do: /api/poll-markets. Auth check. try/finally+atomic lock. Parallel fetch(allSettled). Upsert+nexus. Snapshots(nexus>0). Anomaly(z-score vol+price vs 7d avg, skip<100 snapshots, severity=min(z/5,1), conf=severity*nexus). Whale(conf>0.75 AND nexus>0.5). Resolution detect. update last_success_poller
Check: curl w/secret. Markets populate. Snapshots nexus>0 only. Lock cycles. Kill mid-run→lock auto-releases 3min

### S6: Scoring Engine
Ctx: CLAUDE.md + Engine 2 + Scoring Prompt + Polyseer + Compression + Branding + Pre-Build Bugs
Do: {engine,prompt,parser,models}.ts. ALWAYS Haiku→Sonnet. TWO prompts(research+scoring). web_search tool Stage 1 ONLY. cache_control system msgs. /api/analyze-markets. scorer_lock. Skip-if-unchanged. Partial batch(write returned, log missing). Edge formula. market_price_at_scoring. pick_score+rank. last_success_scorer
Check: picks table populated w/ rationale, key_evidence(grade+side), p_neutral, p_aware, evidence_gap, what_would_change, consistent cycle_id

### S7: Pick Board
Ctx: CLAUDE.md + Dashboard + Social Sharing
Do: canonical JOIN query(+whale OR). Realtime on picks. Cards: rank/title/platform/direction/edge/confidence/crowd/anomaly. Tier filter middleware. Empty state. Upsell teaser. Share+affiliate. Milestone bar
Check: Harpooner sees 25. Live updates. Empty state before first cycle. Share copies affiliate URL

### S8: Pick Detail + Bet Tracker
Ctx: CLAUDE.md + Pick Detail + Bet Tracker + Courtroom display
Do: Rationale, PRO/CON w/grade badges, evidence_gap, what_would_change, risk, sentiment, community. "Bet on [Platform]" link. "I Bet This"(DISABLED resolved/closed, validate $1-$100K, direction-aware entry price). Courtroom btn: Harpooner→modal upsell, FM/Ahab→disabled "Coming Soon". Bet tracker w/direction-aware P&L. Win celebration+share. Feedback: thumbs up/down→user_feedback. Settings "Send Feedback" modal(bug/feature/general)
Check: PRO/CON badges. Bet disabled on resolved. Modal upsell. Log bet→tracker. Share text. Thumbs→user_feedback. Settings feedback works

### S9: Payments
Ctx: CLAUDE.md + Payment Rails + Pre-Build Bugs + Quick Wins(annual,exit survey)
Do: polar.ts+coinremitter.ts. /api/webhook/{fiat,crypto}. Sig verify. Idempotent. Set tier+provider. Crypto:+30d. Commission if referred. Canceled→set expires_at. Chargeback→ban. BOTH monthly+annual Polar products($29+$290). Map both IDs→same tier. Exit survey: pre-redirect modal on settings(dropdown+text)→user_events cancel_initiate
Check: Polar test. Cancel→expiration. Chargeback→ban. Annual creates sub. Exit survey fires event

### S10: Affiliates
Ctx: CLAUDE.md + Affiliate + Referral Chain + Fraud
Do: Referral cookie 90d. After signup set referred_by. /dashboard/referrals. Commission. /api/process-payouts. Self-referral block
Check: 2 accounts. Cookie referral. Commission credited. Dashboard shows

### S11: Notifications + Crowd
Ctx: CLAUDE.md + Notifications + Crowd Aggregation
Do: /api/send-notifications 3/hr throttle. /api/aggregate-crowd: views/bets/watchlist/crowd_yes_pct(0 bets→50.0). Crowd-trending: views>MAX(5*avg,20). Discord webhooks w/embed format
Check: Discord fires. 4th blocked. Crowd fields update. 0 bets=50

### S12: Landing + Pricing + Admin
Ctx: CLAUDE.md + Landing + Competitive Landscape + Admin + Milestones + Quick Wins(status,email,annual)
Do: Landing w/ comparison chart(14 rows). Monthly/annual toggle("Save 17%"). Pre-launch email→waitlist table. Polar+Coinremitter checkout. /status(binary:operational|degraded, MUST use admin client). Footer status badge. Admin: health(RED/YEL/GRN), revenue, errors, affiliates, /admin/feedback
Check: Landing+chart. Toggle switches IDs. Email→waitlist. /status works. Admin colors. Feedback page. Error drill-down

### S13: Onboarding + Events
Ctx: Social Sharing + Notifications + Quick Wins(events)
Do: Welcome modal. Share+affiliate everywhere. /api/check-expirations(BOTH rails+prune snapshots 90d+views 48h). /api/milestone-status. trackEvent(userId,type,metadata) utility. Call from: login, view_pick, place_bet, upgrade_click, share_click, watchlist_add, cancel_confirm, credit_purchase, notification_click. RLS: INSERT only
Check: Onboarding. Share. Expiration downgrades. Pruning. Events in user_events after login/view/bet

### S14: Security + Deploy
Ctx: CLAUDE.md + Security Hardening + Operational Concerns(Polar mode, API playbook)
Do: Rate limit(60/min user, 30/min IP). Sessions(active_sessions, 2/3/5). x-client-id. Bot block. Unicode watermark. CSP. Supabase auth(email confirm, CAPTCHA, 7d). Skeletons+error boundaries+empty states. Middleware: auth→banned→tier NULL→expires_at realtime→session→Supabase-down fallback
DEPLOY CHECKLIST:
- 14 env vars in Vercel prod
- POLAR_MODE=live
- POLAR_WEBHOOK_SECRET=production
- Product IDs=production(monthly+annual)
- Coinremitter=production
- CRON_SECRET matches Vercel
- 7 crons visible+firing
- /status=operational
- Landing+pricing+checkout work
- Test $29 payment→refund
- Browser client CANNOT read error_log/system_state(except mrr_cache)
Check: Full E2E flow. Sessions enforced. Rate limits hit. Watermark in source. All crons running

PHASE 1 COMPLETE. 14 sessions. Wait 72hr stable before Phase 2.

---

# PHASE 2 (7 sessions, ~12 days)
Add to Phase 1. Never modify Phase 1.
New env: ALCHEMY_API_KEY/SECRET, RESEND_API_KEY, TELEGRAM_BOT_TOKEN, POLAR_FIRSTMATE_PRODUCT_ID, HARPOON_ENCRYPTION_SECRET
Migration: 002_phase2.sql(wallet_events, wallet_profiles, byoai counters)

P2-1: Alchemy webhook→wallet_events
P2-2: Wallet tracking+profiling→wallet_profiles
P2-3: /dashboard/wallets UI
P2-4: Telegram+email notifications(add handlers, same throttle)
P2-5: First Mate tier($99 Polar product, update tier-features)
P2-6: /admin/accuracy(charts by confidence/edge/category/time)
P2-7: Courtroom+Credits+BYOAI(3 parts: credit system, 2-call trial+verdict, provider abstraction+encryption+daily cap 300)

# PHASE 3 (8 sessions, ~16 days)
P3-1/2: Backtester engine+UI
P3-3: Wallet clustering(Ahab)
P3-4: REST API(/api/v1/ 100req/hr Ahab)
P3-5/6: Auto-trading engine+UI(Kalshi RSA-PSS, Polymarket wallet, risk limits)
P3-7: SMS(Twilio, Ahab only)
P3-8: Ahab tier launch($299)

# PHASE 3b: Command Center($25K MRR). See arch doc.
# PHASE 4: White Whale($50K MRR). Autonomous AI trading. See arch doc.
