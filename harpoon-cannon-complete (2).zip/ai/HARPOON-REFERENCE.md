# REFERENCE - Harpoon Cannon
Updated 2026-04-16

## What
Prediction market intelligence SaaS. Kalshi+Polymarket. AI scores probability across 8 signals → compares market price → surfaces edge. $29-$299/mo.

## Files (11)
001_initial_schema.sql = DB SOURCE OF TRUTH (19 tables)
CLAUDE.md = paste every coding session
HARPOON-CANNON-v3-FINAL.md = full arch spec ~3700 lines, 11 mermaid diagrams
harpoon-cannon-build-guide.md = 14 Phase 1 sessions
HARPOON-REFERENCE.md = this file
SYNC-PROTOCOL.md = drift prevention, read first
ERROR-HUNTER.md = 407 bugs found+fixed, 9 methods
design.md = Concept C selected, page map, components
design-example-landing.html = visual mockup
progress.md = session tracker
vercel.json = 7 crons

## Stack
Next.js 14+ TS | Supabase | Vercel Pro | Claude API | Polar(fiat) | Coinremitter(crypto) | shadcn/ui

## Engines
Poller(60s): fetch both→upsert→snapshot→anomaly→whale alert→resolution
Scorer(hourly): check kill switch→lock→select WHERE active→Haiku researcher(web search)→Sonnet analyst→parse→validate→write picks

## Tables (19)
markets snapshots anomalies picks user_profiles user_bets user_watchlist market_views payments referrals affiliate_payouts notification_log system_state error_log active_sessions courtroom_verdicts user_events user_feedback waitlist

## Routes (15)
poll-markets(cron/min) | analyze-markets(cron/hr) | analyze-urgent(POST) | webhook/fiat(POST) | webhook/crypto(POST) | send-notifications(POST) | resolve-picks(cron/day) | aggregate-crowd(cron/15min) | track-view(POST) | check-expirations(cron/day) | milestone-status(GET) | process-payouts(cron/month) | validate-models(cron/week Sun 06:00) | courtroom(P2) | settings/byoai(P2)

## Tiers
Harpooner $29/mo|$290/yr: Pool A(nexus>=0.7) 25 picks. Credits:0. Cap:0. BYOAI:locked
First Mate $99/mo|$990/yr: Pool A+B(nexus>=0.3) 50 picks. Credits:150/mo. Cap:20/day. BYOAI:300/day
Ahab $299/mo|$2990/yr: All. Unlimited. Credits:500/mo. Cap:50/day. BYOAI:300/day

## Fiscal
Background scoring: ~$750-1100/mo FIXED
Break-even @$29: 26-38 subs
Per-user on-demand worst case: FM $2.10/mo(2.1%) | Ahab $7/mo(2.3%) | BYOAI $0
Top-ups: Boost $4.99/100cr(72% margin) | Power $12.99/300cr(68%) | Unlimited $34.99/1000cr(60%)
Affiliate 25% recurring. Clawback on chargeback+refund
Steady state(100H+20FM+5A): MRR $6,375. Margin ~83%
Annual: H $290/yr($24.17/mo) | FM $990/yr($82.50/mo) | A $2990/yr($249/mo). All profitable

## Env Vars Phase 1 (14)
NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY, ANTHROPIC_API_KEY, POLAR_ACCESS_TOKEN, POLAR_WEBHOOK_SECRET, POLAR_HARPOONER_PRODUCT_ID, POLAR_HARPOONER_ANNUAL_PRODUCT_ID, COINREMITTER_API_KEY, COINREMITTER_PASSWORD, HARPOON_INTERNAL_SECRET, CRON_SECRET, NEXT_PUBLIC_APP_URL, POLAR_MODE

## Build Order
P1: 14 sessions→ship Harpooner. Wait 72hr stable
P2: 7 sessions→Courtroom+BYOAI+wallets+FM tier
P3: 8 sessions→backtester+API+auto-trade+Ahab
P3b: Command Center. P4: White Whale(autonomous)

## Status
Pre-build. 426 issues fixed (407 + 19 from Audit N 2026-04-17). Production readiness passed. Ready Session 1.
